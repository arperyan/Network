define([
    'jquery',
    'qlik',
    'qvangular'
],
    function ($, qlik, qvangular) {
        'use strict';

        return {
            initialProperties: {
                version: 1.0,
                qHyperCubeDef: {
                    qDimensions: [],
                    qMeasures: [],
                    qInitialDataFetch: [{
                        qWidth: 2,
                        qHeight: 50
                    }]
                }
            },

            definition: {
                type: "items",
                component: "accordion",
                items: {
                    dimensions: {
                        uses: "dimensions",
                        min: 1,
                        max: 1
                    },
                    measures: {
                        uses: "measures",
                        min: 1,
                        max: 1
                    },
                    sorting: {
                        uses: "sorting"
                    },
                    settings: {
                        uses: "settings"
                    }
                }
            },

            support: {
                snapshot: true, // needed for Stories
                export: true    // Export Data menu
            },

            // PrePaint when object size changes
            resize: function ($element, layout) {
                console.log("resize", this, $element, layout);
                this.paint($element, layout);
            },

            paint: function ($element, layout) {
                console.log("paint", this, $element, layout);
                var scope = $element.scope(); // context of container directive
                var sheet = scope.$parent;    // the sheet context
                var root = sheet.$root;      // the app context, don't name it app!

                // store a property on app level, consitent when sheet changes
                if (!root.hasOwnProperty("myProp")) {
                    root.myProp = new Date();
                }
                // store a property on sheet level, consitent when model changes (selections) and paint is called again
                if (!sheet.hasOwnProperty("myProp")) {
                    sheet.myProp = new Date();
                }
                console.log("Root --->", root.myProp);
                console.log("Sheet -->", sheet.myProp);

                // container object width
                var width = $element.width(); // space left for scrollbar
                // container object height
                var height = $element.height();
                // container object id
                var id = "container-" + layout.qInfo.qId;
                var container = {};
                var helloWorld = 'Hello World from the extension "SimpleHelloWorld"<br/>';

                // Check to see if the chart element has already been created
                if ($("#" + id)[0]) {
                    // if it has been created, empty it's contents so we can redraw it
                    container = $("#" + id);
                    container.empty();
                } else {
                    //if it hasn't been created, create it with the appropriate id and size
                    container = $('<div />').attr({
                        "id": id
                    }).css({
                        "height": height,
                        "width": width,
                        "overflow": 'auto'
                    });
                    $element.append(container);
                }
                container.html(helloWorld);

                // // Solve printing issues
                return qlik.Promise.resolve();
            }
        };
    });